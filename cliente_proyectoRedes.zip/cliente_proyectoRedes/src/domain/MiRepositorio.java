/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

import java.io.Serializable;

/**
 *
 * @author ronal
 */
public class MiRepositorio implements Serializable{
    
     public String repositorioUsuario;
     public String listaRepositorios;
     public String listaNoCompartidos;
}
