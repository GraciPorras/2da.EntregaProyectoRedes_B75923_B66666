/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cliente_proyectoredes;

import data.Conexion;
import domain.Fichero;
import domain.MiRepositorio;
import domain.Utilidades;
import domain.pideRuta;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Graciela Porras
 */
public class myClient extends Thread {

    private int socketPortNumber;// numero donde se va a guardar puerto
    public Socket socket;
    public String address;
    Conexion c;
    ObjectOutputStream oos;
    int enviaElSiguiente;
    String nombreUsuario;
    Utilidades utilidades;

    public myClient(int socketPortNumber) throws IOException {
        this.socketPortNumber = socketPortNumber;
        this.address = "localhost";
        this.socket = new Socket(address, this.socketPortNumber);
        oos = new ObjectOutputStream(socket.getOutputStream());
        utilidades = new Utilidades();
    }

    @Override
    public void run() {

    }

    public void recibirNombreUsuario(String nombre) {
        this.nombreUsuario = nombre;
    }

    public void enviaFichero(String fichero, Socket socket, String rutaBDServer) {
        try {

            String nombreArchivo = sacarNombreArchivo(fichero);
            System.out.println("El fichero es: " + fichero);

            //oos = new ObjectOutputStream(socket.getOutputStream());
            boolean enviadoUltimo = false;
            FileInputStream fis = new FileInputStream(fichero);

            // Se instancia y rellena un mensaje de envio de fichero
            Fichero mensaje = new Fichero();
            mensaje.nombreFichero = rutaBDServer + "/" + nombreArchivo;
            //mensaje.nombreFichero = fichero;

            // Se leen los primeros bytes del fichero en un campo del mensaje
            int leidos = fis.read(mensaje.contenidoFichero);

            mensaje.contenidoEncriptado = utilidades.encryptData("SOTITAPSERT", mensaje.contenidoFichero);

            // Bucle mientras se vayan leyendo datos del fichero
            while (leidos > -1) {

                // Se rellena el n�mero de bytes leidos
                mensaje.bytesValidos = leidos;

                // Si no se han leido el m�ximo de bytes, es porque el fichero
                // se ha acabado y este es el �ltimo mensaje
                if (leidos < Fichero.LONGITUD_MAXIMA) {
                    mensaje.ultimoMensaje = true;

                    enviadoUltimo = true;
                } else {
                    mensaje.ultimoMensaje = false;
                }
                // Se env�a por el socket

                //Thread.sleep(2);
                //System.out.println("1"+Arrays.toString(mensaje.contenidoEncriptado));
                oos.writeObject(mensaje);

                // Si es el �ltimo mensaje, salimos del bucle.
                if (mensaje.ultimoMensaje) {
                    System.out.println("PASE AL SIGUIENTE");
                    break;
                }

                // Se crea un nuevo mensaje
                mensaje = new Fichero();
                mensaje.nombreFichero = fichero;

                // y se leen sus bytes.
                leidos = fis.read(mensaje.contenidoFichero);
                mensaje.contenidoEncriptado = utilidades.encryptData("SOTITAPSERT", mensaje.contenidoFichero);
            }

            if (enviadoUltimo == false) {
                mensaje.ultimoMensaje = true;
                mensaje.bytesValidos = 0;
                oos.writeObject(mensaje);

            }
            // Se cierra el ObjectOutputStream
            //oos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        enviaElSiguiente = 1;
    }

    public String sacarNombreArchivo(String fichero) {
        String nombreArchivo = "";
        int cont = 0;
        for (int i = 0; i < fichero.length(); i++) {
            if (fichero.charAt(i) == '\\' || fichero.charAt(i) == '/') {
                cont++;
            }
        }
        String nuevoFichero;
        nuevoFichero = fichero.replace('\\', '/');
        System.out.println(">>" + nuevoFichero);
        System.out.println("Hay " + cont + " de /");
        String[] partes = nuevoFichero.split("/");
        nombreArchivo = partes[cont];
        System.out.println("El nombre del archivo es: " + nombreArchivo);

        return nombreArchivo;
    }

    public void pide(String fichero, Socket socket) {
        try {

            // Se env�a un mensaje de petici�n de fichero.
            pideRuta mensaje = new pideRuta();
            mensaje.nombreFichero = fichero;
            oos.writeObject(mensaje);

            // Se abre un fichero para empezar a copiar lo que se reciba.
            System.out.println("fich--->" + fichero);
            String nombreArchivo = sacarNombreArchivo(fichero);
            System.out.println("nombreeeeee" + nombreArchivo);
            FileOutputStream fos = new FileOutputStream("MisArchivos/" + nombreArchivo);

            // Se crea un ObjectInputStream del socket para leer los mensajes
            // que contienen el fichero.
            System.out.println("1");
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            System.out.println("2");
            Fichero mensajeRecibido;
            Object mensajeAux;
            do {
                // Se lee el mensaje en una variabla auxiliar
                mensajeAux = ois.readObject();

                //System.out.println(">>>>>"+ois.readObject().toString());
                // Si es del tipo esperado, se trata
                if (mensajeAux instanceof Fichero) {
                    System.out.println("aaaaaaaaaaaaaaaa");
                    mensajeRecibido = (Fichero) mensajeAux;
                    // Se escribe en pantalla y en el fiche

                    fos.write(utilidades.decryptData("SOTITAPSERT", mensajeRecibido.contenidoEncriptado), 0, mensajeRecibido.bytesValidos);
                } else {
                    // Si no es del tipo esperado, se marca error y se termina
                    // el bucle
                    System.err.println("Mensaje no esperado "
                            + mensajeAux.getClass().getName());
                    break;
                }
            } while (!mensajeRecibido.ultimoMensaje);

            // Se cierra socket y fichero
            fos.close();
            //ois.close();
            //socket.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String pideRepositorio(String nombreUsuario, Socket socket) {
        String listaRepositorio = "";
        try {

            // Se env�a un mensaje de petici�n de fichero.
            System.out.println("1");
            MiRepositorio mensaje = new MiRepositorio();
            String sCarpAct = "Compartidos";
            File carpeta = new File(sCarpAct);
            String[] listado = carpeta.list();
            String listaRepositorios = "";
            if (listado == null || listado.length == 0) {
                System.out.println("No hay elementos dentro de la carpeta actual");
                mensaje.repositorioUsuario = nombreUsuario;
            } else {
                listaRepositorios = ";";
                for (int i = 0; i < listado.length; i++) {
                    listaRepositorios += listado[i] + ":";
                }
                System.out.println(listaRepositorios);

                mensaje.repositorioUsuario = nombreUsuario + listaRepositorios;

            }
            System.out.println("Escribi el mensaje");
            oos.writeObject(mensaje);

            System.out.println("Ahora continuo");
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());

            Object mensajeAux;
            mensajeAux = ois.readObject();
            if (mensajeAux instanceof MiRepositorio) {
////                System.out.println("NOMMBRE QUE ENVIARE");
                MiRepositorio listaRepo = (MiRepositorio) mensajeAux;
                System.out.println(">>>" + listaRepo.listaRepositorios);
                String[] partes = listaRepo.listaRepositorios.split(";");

                System.out.println("Lista->" + partes[0]);
                listaRepositorio = partes[0];

                //recibe aqui los archivos que aun no estan en el servidor
                System.out.println("Lista de archivos que no tiene el server y tengo que enviarle");
                if (partes.length < 1) {
                    System.out.println(partes[1]);
                    if (partes[1].equalsIgnoreCase("NULL")) {
                        System.out.println("NO HAY ARCHIVOS QUE ENVIAR");
                    } else {
                        enviarArchivosCompartidos(sacarVectorRepositorios(partes[1]));
                    }
                } 

            } else {

                System.err.println("Mensaje no esperado "
                        + mensajeAux.getClass().getName());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaRepositorio;
    }

    public ArrayList<String> sacarVectorRepositorios(String listaRepositorios) {
        ArrayList<String> listaRepos = new ArrayList<String>();
        int cont = 0;
        for (int i = 0; i < listaRepositorios.length(); i++) {
            if (listaRepositorios.charAt(i) == ':') {
                cont++;
            }
        }
        System.out.println("Hay " + cont + " de :");
        String[] partes = listaRepositorios.split(":");
        for (int i = 0; i < cont; i++) {
            listaRepos.add(partes[i]);
            System.out.println("El nombre del archivo es: " + listaRepos.get(i));
        }
        return listaRepos;
    }

    public void enviarArchivosCompartidos(ArrayList<String> lista) {
        String user = System.getProperty("user.name");
        String url = "";
        String url2 = "Compartidos/";
        enviaElSiguiente = 0;
        System.out.println("LA LISTA:" + lista.size());
        for (int i = 0; i < lista.size(); i++) {
            url = "C:\\Users\\" + user + "\\Documents\\Servidor_ProyectoRedes\\CarpetasUsuario\\" + this.nombreUsuario + "\\Compartidos" + "\\";
            enviaFichero(url2 + lista.get(i), socket, url);
            while (enviaElSiguiente == 0) {
                System.out.println("SIGO ENVIANDO");
            }
            System.out.println("PODEMOS CONTINUAR>>>>>>>>>>>>");
            enviaElSiguiente = 0;
        }
    }

    public int getSocketPortNumber() {
        return socketPortNumber;
    }

    public void setSocketPortNumber(int socketPortNumber) {
        this.socketPortNumber = socketPortNumber;
    }

    public Socket getSocket() {
        return socket;
    }

    public void setSocket(Socket socket) {
        this.socket = socket;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

}
