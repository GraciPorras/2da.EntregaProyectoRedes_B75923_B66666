/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidor_proyectoredes;

import domain.Fichero;
import domain.MiRepositorio;
import domain.Utilidades;
import domain.pideRuta;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Arrays;

class GestionDeCliente extends Thread {

    Socket socket;
    ObjectOutputStream oos;
    private ArrayList<GestionDeCliente> gestionClienteArray;
    ArrayList<String> listadoArchivosCompartidos = new ArrayList<String>();
    String mensajeBorrar = "";
    Utilidades utilidades;

    public GestionDeCliente(Socket socket, ArrayList gestionClienteArray) {
        this.socket = socket;
        this.utilidades = new Utilidades();
        this.gestionClienteArray = gestionClienteArray;
    }

    @Override
    public void run() {
        escucha(socket);

    }

    public void escucha(Socket cliente) {
        try {

            //System.out.println("Aceptado cliente");
            ObjectInputStream ois = new ObjectInputStream(cliente.getInputStream());

            while (true) {

                Object mensaje = ois.readObject();

                if (mensaje instanceof pideRuta) {
                    //System.out.println("Me piden: "
                    // + ((pideRuta) mensaje).nombreFichero);
                    enviaFichero(((pideRuta) mensaje).nombreFichero,
                            new ObjectOutputStream(cliente.getOutputStream()));
//Ya Ya casi termino con Elena jajaja pero no tijeras xD
                } else if (mensaje instanceof Fichero) {
                    //System.out.println("eeeeeeeeeeeeeeeeee");
                    Fichero mensajeRecibido = (Fichero) mensaje;
                    //System.out.println("ENCRIPTADO");
                    //System.out.println(Arrays.toString(mensajeRecibido.contenidoEncriptado));

                    FileOutputStream fos = new FileOutputStream(mensajeRecibido.nombreFichero);
                    //System.out.println("DESENCRIPTADO");
                    //System.out.println("1" + Arrays.toString(utilidades.decryptData("SOTITAPSRET", mensajeRecibido.contenidoEncriptado)));
                    fos.write(utilidades.decryptData("SOTITAPSERT", mensajeRecibido.contenidoEncriptado), 0, mensajeRecibido.bytesValidos);
                    //System.out.println("INICIO"+Arrays.toString(mensajeRecibido.contenidoFichero));
                    Object mensajeAux;
                    do {
                        //System.out.println(Arrays.toString(mensajeRecibido.contenidoFichero));
                        mensajeAux = ois.readObject();

                        if (mensajeAux instanceof Fichero) {

                            mensajeRecibido = (Fichero) mensajeAux;

                            //System.out.print(new String(
                            //mensajeRecibido.contenidoFichero, 0,mensajeRecibido.bytesValidos));
                            //System.out.println("ENCRIPTADO");
                            //System.out.println(Arrays.toString(mensajeRecibido.contenidoEncriptado));
                            System.out.println("DESENCRIPTADO");
                            //System.out.println("2" + Arrays.toString(utilidades.decryptData("SOTITAPSERT", mensajeRecibido.contenidoEncriptado)));
                            //System.out.println("3"+Arrays.toString(mensajeRecibido.contenidoFichero));
                            fos.write(utilidades.decryptData("SOTITAPSERT", mensajeRecibido.contenidoEncriptado), 0, mensajeRecibido.bytesValidos);
                        } else {

                            System.err.println("Mensaje no esperado "
                                    + mensajeAux.getClass().getName());
                            break;
                        }

                    } while (!mensajeRecibido.ultimoMensaje);

                    //fos.close();
                    //ois.close();
                } else if (mensaje instanceof MiRepositorio) {
                    MiRepositorio mensajeRecibido = (MiRepositorio) mensaje;
                    System.out.println(mensajeRecibido.repositorioUsuario);

                    //Recibi el listado de los nombres de arhivos que estan compartidos
                    String[] partes = mensajeRecibido.repositorioUsuario.split(";");
                    String listaRepositorios = "";
                    String mensajeAEnviar = "NULL";
                    if (partes.length < 1) {

                        System.out.println("El listado es=>" + partes[1]);
                        listadoArchivosCompartidos = sacarArrayCompartidos(partes[1]);
                        ArrayList<String> nolostengo = new ArrayList<String>();
                        nolostengo = verificarArchivosCompartidos(listadoArchivosCompartidos, partes[0]);
                        
                        for (int i = 0; i < nolostengo.size(); i++) {
                            System.out.println("Entre");
                            if (i == 0) {
                                mensajeAEnviar = "";
                            }
                            mensajeAEnviar += nolostengo.get(i) + ":";
                        }
                        System.out.println("SE ENVIARA:" + mensajeAEnviar);
                        
                        //fin del listado
                    } else {
                        //envio mi listado desde la parte servidor
                        String nombreUsuario = partes[0];
                        System.out.println("NOMBRE:" + nombreUsuario);
                        String sCarpAct = "CarpetasUsuario/" + nombreUsuario;
                        File carpeta = new File(sCarpAct);
                        String[] listado = carpeta.list();
                        
                        if (listado == null || listado.length == 0) {
                            System.out.println("No hay elementos dentro de la carpeta actual");
                        } else {
                            for (int i = 0; i < listado.length; i++) {
                                if (!listado[i].equalsIgnoreCase("Compartidos")) {
                                    listaRepositorios += listado[i] + ":";
                                }
                            }
                            System.out.println(listaRepositorios);
                        }
                    }
                    if(partes.length<1){
                        oos = new ObjectOutputStream(cliente.getOutputStream());
                        ((MiRepositorio) mensaje).listaRepositorios = listaRepositorios + ";" + mensajeAEnviar;
                    }else{
                        oos = new ObjectOutputStream(cliente.getOutputStream());
                        ((MiRepositorio) mensaje).listaRepositorios = listaRepositorios;
                    }
                    
                    System.out.println("Estoy escribiendo al cliente");
                    oos.writeObject(mensaje);
                    System.out.println("Ahora continuo");

                } else {
                    // Si no es el mensaje esperado, se avisa y se sale todo.
                    System.err.println(
                            "Mensaje no esperado " + mensaje.getClass().getName());
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void enviaFichero(String fichero, ObjectOutputStream oos) {
        try {

            //System.out.println("sssssssssssssssssssss");
            boolean enviadoUltimo = false;
            // Se abre el fichero.
            FileInputStream fis = new FileInputStream(fichero);

            // Se instancia y rellena un mensaje de envio de fichero
            Fichero mensaje = new Fichero();
            mensaje.nombreFichero = fichero;

            // Se leen los primeros bytes del fichero en un campo del mensaje
            int leidos = fis.read(mensaje.contenidoFichero);
            mensaje.contenidoEncriptado = utilidades.encryptData("SOTITAPSERT", mensaje.contenidoFichero);
            // Bucle mientras se vayan leyendo datos del fichero
            while (leidos > -1) {

                // Se rellena el n�mero de bytes leidos
                mensaje.bytesValidos = leidos;

                // Si no se han leido el m�ximo de bytes, es porque el fichero
                // se ha acabado y este es el �ltimo mensaje
                if (leidos < Fichero.LONGITUD_MAXIMA) {
                    mensaje.ultimoMensaje = true;
                    enviadoUltimo = true;
                } else {
                    mensaje.ultimoMensaje = false;
                }
                // Se env�a por el socket
                oos.writeObject(mensaje);

                // Si es el �ltimo mensaje, salimos del bucle.
                if (mensaje.ultimoMensaje) {
                    break;
                }

                // Se crea un nuevo mensaje
                mensaje = new Fichero();
                mensaje.nombreFichero = fichero;

                // y se leen sus bytes.
                leidos = fis.read(mensaje.contenidoFichero);
                mensaje.contenidoEncriptado = utilidades.encryptData("SOTITAPSERT", mensaje.contenidoFichero);
            }

            if (enviadoUltimo == false) {
                mensaje.ultimoMensaje = true;
                mensaje.bytesValidos = 0;
                oos.writeObject(mensaje);
            }
            // Se cierra el ObjectOutputStream
            //oos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void enviaMiReposotorio(String fichero, ObjectOutputStream oos) {
        try {

            //System.out.println("sssssssssssssssssssss");
            boolean enviadoUltimo = false;
            // Se abre el fichero.
            FileInputStream fis = new FileInputStream(fichero);

            // Se instancia y rellena un mensaje de envio de fichero
            Fichero mensaje = new Fichero();
            mensaje.nombreFichero = fichero;

            // Se leen los primeros bytes del fichero en un campo del mensaje
            int leidos = fis.read(mensaje.contenidoFichero);
            mensaje.contenidoEncriptado = utilidades.encryptData("SOTITAPSERT", mensaje.contenidoFichero);
            // Bucle mientras se vayan leyendo datos del fichero
            while (leidos > -1) {

                // Se rellena el n�mero de bytes leidos
                mensaje.bytesValidos = leidos;

                // Si no se han leido el m�ximo de bytes, es porque el fichero
                // se ha acabado y este es el �ltimo mensaje
                if (leidos < Fichero.LONGITUD_MAXIMA) {
                    mensaje.ultimoMensaje = true;
                    enviadoUltimo = true;
                } else {
                    mensaje.ultimoMensaje = false;
                }
                // Se env�a por el socket
                oos.writeObject(mensaje);

                // Si es el �ltimo mensaje, salimos del bucle.
                if (mensaje.ultimoMensaje) {
                    break;
                }

                // Se crea un nuevo mensaje
                mensaje = new Fichero();
                mensaje.nombreFichero = fichero;

                // y se leen sus bytes.
                leidos = fis.read(mensaje.contenidoFichero);
                mensaje.contenidoEncriptado = utilidades.encryptData("SOTITAPSERT", mensaje.contenidoFichero);
            }

            if (enviadoUltimo == false) {
                mensaje.ultimoMensaje = true;
                mensaje.bytesValidos = 0;
                oos.writeObject(mensaje);
            }
            // Se cierra el ObjectOutputStream
            //oos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<String> sacarArrayCompartidos(String listaRepositorios) {
        ArrayList<String> listaRepos = new ArrayList<String>();
        int cont = 0;
        for (int i = 0; i < listaRepositorios.length(); i++) {
            if (listaRepositorios.charAt(i) == ':') {
                cont++;
            }
        }
        System.out.println("Hay " + cont + " de :");
        String[] partes = listaRepositorios.split(":");
        for (int i = 0; i < cont; i++) {
            listaRepos.add(partes[i]);
            System.out.println("El nombre del archivo es: " + listaRepos.get(i));
        }
        return listaRepos;
    }

    public ArrayList<String> verificarArchivosCompartidos(ArrayList<String> listadoUsuario, String nombreUsuario) {
        ArrayList<String> listaComparar = new ArrayList<String>();
        ArrayList<String> salida = new ArrayList<String>();
        String sCarpAct = "CarpetasUsuario/" + nombreUsuario + "/Compartidos";
        File carpeta = new File(sCarpAct);
        String[] listado = carpeta.list();
        String listaRepositorios = "";
        if (listado == null || listado.length == 0) {
            System.out.println("No hay elementos dentro de la carpeta actual");
        } else {
            for (int i = 0; i < listado.length; i++) {
                listaRepositorios += listado[i] + ":";
            }
            System.out.println(listaRepositorios);
        }
        listaComparar = sacarArrayCompartidos(listaRepositorios);
        salida = compararArrays(listadoUsuario, listaComparar, nombreUsuario);
        return salida;
    }

    public ArrayList<String> compararArrays(ArrayList<String> listadoUsuario, ArrayList<String> listadoServidor, String nombreUsuario) {
        String mensajeABorrar = "";
        ArrayList<String> salida = new ArrayList<String>();
        ArrayList<String> compartidos = new ArrayList<String>();
        System.out.println("LISTA USUARIO");
        for (int i = 0; i < listadoUsuario.size(); i++) {
            System.out.println(listadoUsuario.get(i));
        }
        System.out.println("LISTA SERVER");
        for (int i = 0; i < listadoServidor.size(); i++) {
            System.out.println(listadoServidor.get(i));
        }
        for (int i = 0; i < listadoUsuario.size(); i++) {
            for (int j = 0; j < listadoServidor.size(); j++) {
                if (listadoUsuario.get(i).equals(listadoServidor.get(j))) {
                    System.out.println("Ambos tienen el archivo:" + listadoServidor.get(j));
                    listadoUsuario.remove(i);
                    if (listadoUsuario.size() == 0) {
                        listadoUsuario.add("");
                    } else {
                        for (int k = 0; k < listadoUsuario.size(); k++) {
                            System.out.println(listadoUsuario.get(k));
                        }
                    }
                } else {

                    System.out.println("Estos son los que no son iguales=" + listadoServidor.get(j));
                    mensajeABorrar += listadoServidor.get(j) + ":";
                }
            }
        }
        System.out.println("MensajeAborrar=" + mensajeABorrar);
        mensajeBorrar = mensajeABorrar;
        borrarArchivo(mensajeBorrar, nombreUsuario);
        System.out.println("ARCCHIVOS QUE DEBE DE PEDIR EL SERVIDOR");
        for (int j = 0; j < listadoUsuario.size(); j++) {
            if (listadoUsuario.get(j).equals("")) {
                listadoUsuario.remove(j);
            }
        }
        for (int i = 0; i < listadoUsuario.size(); i++) {
            System.out.println(listadoUsuario.get(i));
        }

        return listadoUsuario;
    }

    /*public void verSiDeboEliminar(ArrayList<String> listadoUsuario, ArrayList<String> listadoServidor) {
        String mensajeABorrar = "";
        System.out.println("LISTA USUARIO");
        for (int i = 0; i < listadoUsuario.size(); i++) {
            System.out.println(listadoUsuario.get(i));
        }
        System.out.println("LISTA SERVER");
        for (int i = 0; i < listadoServidor.size(); i++) {
            System.out.println(listadoServidor.get(i));
        }
        for (int i = 0; i < listadoUsuario.size(); i++) {//5
            for (int j = 0; j < listadoServidor.size(); j++) {//4
                if (listadoUsuario.get(i).equals(listadoServidor.get(j))) {
                    System.out.println("Lista usuario:" + listadoUsuario.get(i));
                    System.out.println("Ambos tienen el archivo:" + listadoServidor.get(j));
                    System.out.println("i:" + i + "J:" + j);

                    listadoUsuario.remove(i);
                    if (listadoUsuario.size() == 0) {
                        listadoUsuario.add("");
                    } else {
                        for (int k = 0; k < listadoUsuario.size(); k++) {
                            System.out.println(listadoUsuario.get(k));
                        }
                    }
                } else {
                    System.out.println("Estos son los que no son iguales=" + listadoServidor.get(j));
                    mensajeABorrar += listadoServidor.get(j) + ":";
                }
            }
        }
        System.out.println("MensajeAborrar=" + mensajeABorrar);
        mensajeBorrar = mensajeABorrar;
        //0==0 //0==1/0==2/
        //
        //
        //
        //
        //
    }*/
    public void borrarArchivo(String mensajeBorrar, String nombreUsuario) {
        ArrayList<String> salida = new ArrayList<String>();
        salida = sacarArrayCompartidos(mensajeBorrar);
        File fichero;
        String user = System.getProperty("user.name");
        for (int i = 0; i < salida.size(); i++) {
            fichero = new File("C:/Users/" + user + "/Documents/Servidor_ProyectoRedes/CarpetasUsuario/" + nombreUsuario + "/Compartidos/" + salida.get(i));
            if (fichero.delete()) {
                System.out.println("El fichero ha sido borrado satisfactoriamente");
            } else {
                System.out.println("El fichero no puede ser borrado");
            }
        }
    }
}
