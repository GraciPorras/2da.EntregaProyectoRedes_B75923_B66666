/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bff;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author ronal
 */
public class Logica {

    public void ejercicio1() {
        String x = "";
        x = JOptionPane.showInputDialog(null, "Ingrese la frase que desee");
        String y = "";

        y = x.replaceAll(" ", "");
        System.out.println("El texto ingresado sin los espacios en blanco es: " + "\n" + y);
    }

    public void ejercicio2() {

        Scanner sc = new Scanner(System.in);

        int dia, seg;

        System.out.println("Ingrese la cantidad de días a los que desea calcular los segundos: ");

        dia = sc.nextInt();
        seg = dia * 86400;

        System.out.println("La cantidad de segundos en " + dia + " dias es: " + seg + "s.");

    }

    public void ejercicio3() {
        String hora = "";

        hora = JOptionPane.showInputDialog(null, "Ingresa la hora que desea calcular");
        int horas = 0;
        int minutos = 0;
        int segundos = 0;
        String[] dia = hora.split(":");
        int segundosTotales = 0;
        horas = Integer.parseInt(dia[0]);
        minutos = Integer.parseInt(dia[1]);
        segundos = Integer.parseInt(dia[2]);
        JOptionPane.showMessageDialog(null, "La hora ingresada tiene " + horas + " horas, " + minutos + " minutos y " + segundos + " segundos");
        segundosTotales += horas * 3600;
        segundosTotales += minutos * 60;
        segundosTotales += segundos;
        JOptionPane.showMessageDialog(null, "La hora ingresada " + hora + " en el dia han transcurrido " + segundosTotales + " segundos");
    }

    public void ejercicio4() throws ParseException {
        Date objDate = new Date();
        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        System.out.println(formatoFecha.format(objDate));
        String fechaActual = (formatoFecha.format(objDate));
        String fechainicio = JOptionPane.showInputDialog(null, "Ingrese la fecha inicial \nPor ejemplo: 12/12/1989");
        Date fechaInicial = formatoFecha.parse(fechainicio);
        Date fechaFinal = formatoFecha.parse(fechaActual);
        int dias = 0;
        dias = (int) ((fechaFinal.getTime() - fechaInicial.getTime()) / 86400000);
        JOptionPane.showMessageDialog(null, "Hay " + dias + " dias de diferencia desde la fecha: " + fechainicio + " hasta la fecha actual :" + fechaActual);
    }
}
